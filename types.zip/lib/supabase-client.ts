// Este archivo está deprecado. Usa '@/lib/supabase-browser' en su lugar.
export { supabase } from "@/lib/supabase-browser"